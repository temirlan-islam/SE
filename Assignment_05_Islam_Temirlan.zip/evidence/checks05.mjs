import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
import {registerHooks} from 'node:module';
registerHooks({resolve(s,c,next){return next(s === './availability' ? './availability.ts' : s,c)}});
const root=resolve(process.argv[2] ?? '.');
const read = n => JSON.parse(readFileSync(resolve(root,n),'utf8'));
const {checkAvailability}=await import(pathToFileURL(resolve(root,'src/availability.ts')));
const {reasonCodeFor}=await import(pathToFileURL(resolve(root,'src/explanation.ts')));
test('unused Supabase dependency and ws path removed',()=>{
 assert.ok(!('@supabase/supabase-js' in read('package.json').dependencies));
 const pkgs=Object.keys(read('package-lock.json').packages);
 assert.ok(!pkgs.some(k=>k.endsWith('/ws')||k.endsWith('/@supabase/supabase-js')));
});
test('reason code survives a display copy edit',()=>{
 const verdict=checkAvailability(630,690,false);
 assert.equal(reasonCodeFor({...verdict,reason:'Time conflict.'}),'OVERLAP');
});
for(const [name,start,end,blocked,expected] of [
 ['now',540,600,false,'PAST'],['order',700,690,false,'INVALID_TIME'],['fractions',700.5,750,false,'INVALID_TIME'],['day end',1400,1441,false,'OUT_OF_RANGE'],['120 minutes',720,840,false,'AVAILABLE'],['121 minutes',720,841,false,'TOO_LONG'],['blocked',720,750,true,'BLOCKED'],['overlap',630,690,false,'OVERLAP'],['left endpoint',541,600,false,'AVAILABLE'],['right endpoint',660,720,false,'AVAILABLE']]){
 test(name,()=>{const bookings=[[600,660]];assert.equal(reasonCodeFor(checkAvailability(start,end,blocked,bookings)),expected);assert.deepEqual(bookings,[[600,660]])});
}
