# Student terminal evidence

Transcription of the three supplied PowerShell screenshots.

| Command | My Linux baseline | My final Windows run |
|---|---|---|
| `npm ci` | Installed from the lockfile. | Added 303 packages and audited 304 in 54 s. Full install audit reported 24 vulnerabilities (2 low, 7 moderate, 13 high, 2 critical). |
| `npm test` | Vitest 2.1.9. 28/28 passed across 3 files. | Vitest 2.1.9. 29/29 passed across 3 files in 805 ms. Availability 9, explanation 17, preview 3. |
| `npm run typecheck` | Exit 0. | TypeScript returned to the prompt with no errors shown. |
| `npm run lint` | Exit 0. | No lint errors shown. The parser warned that installed TypeScript 5.6.3 is outside its supported range (>=4.7.4 and <5.6.0). |
| `npm run build` | Vite 5.4.8. 1571 modules in 1.86 s. JS 162.55 kB (51.40 kB gzip). Outdated caniuse-lite warning. Exit 0. | Built 1571 modules in 2.26 s with Vite 5.4.8. HTML 0.71 kB, CSS 15.13 kB, JS 162.34 kB (51.35 kB gzip). Same Browserslist warning. |
| `npm run audit` | One high-severity ws finding via Supabase. Exit 1. | `npm audit --omit=dev` reported 0 vulnerabilities. |
| `npm run dev` | Not run. | Not run. Desktop and mobile views unverified. |