# Software Engineering Assignment 05
**Temirlan Islam · Smart Campus Room Availability Checker · 21 November 2026**

## 1 Repository and baseline

I used [temirlan-islam/SE](https://github.com/temirlan-islam/SE), folder `project/`. My recorded baseline is `7cd4349`, after Practice Work 10. This report compares the uploaded source export with the final source export in this package. The ZIP has no Git history, so the baseline commit is my reference. The final version is identified by the file manifest in `evidence/final-sha256.txt`.

Room 301 has one fictional booking from 10:00 to 11:00. The clock stays at 09:00. My app answers an availability question. It has no login, database or booking creation. I selected five criteria from the README. The examples below give expected outcomes.

| Criterion | Example in whole minutes |
|---|---|
| Times must be integers within the day, with start strictly after 540 and before end. | 540–600, 700–690 and 1400–1441 must be rejected. |
| The maximum duration is 120 minutes. | 720–840 is allowed in an open room. 720–841 is too long. |
| A blocked room is unavailable. | Reject 720–750 when the switch is on. |
| Reject true overlaps and allow touching endpoints. | Reject 630–690. Allow 541–600 and 660–720 in an open room. |
| A check leaves booking data unchanged. | The sample must still be [[600,660]] after a verdict. |

## 2 Repository map and checks

| Path | Responsibility |
|---|---|
| `index.html`, `src/main.tsx`, `src/App.tsx` | The page loads React. The root renders App, which handles input, the blocked switch, timeline, verdict and explanation. |
| `src/availability.ts` | Owns the fixed data and the pure decision function. |
| `src/preview.ts` | Parses an interval for the timeline. |
| `src/explanation.ts` | Builds requests, validates the mock adapter response and provides a fallback. |
| `src/{availability,preview,explanation}.test.ts` | Tests for the three modules. Vitest includes tests under src. The intentional exercise in `.practice08-bug-a/` is excluded. |
| `package.json`, lockfile and config files | npm scripts call Vitest, TypeScript, ESLint and Vite. React and Lucide supply the interface. Tailwind supplies styles. The baseline also declared Supabase. |

I ran the baseline commands on Linux. I then ran the final checks in PowerShell from the extracted project folder. The final column transcribes my three terminal screenshots. They show results and warnings but do not print numeric exit codes. Earlier Codex logs in the archive describe its restricted environment.

| Command | My Linux baseline | My final Windows run |
|---|---|---|
| `npm ci` | Installed from the lockfile. | Added 303 packages and audited 304 in 54 s. Full install audit reported 24 vulnerabilities (2 low, 7 moderate, 13 high, 2 critical). |
| `npm test` | Vitest 2.1.9. 28/28 passed across 3 files. | Vitest 2.1.9. 29/29 passed across 3 files in 805 ms. Availability 9, explanation 17, preview 3. |
| `npm run typecheck` | Exit 0. | TypeScript returned to the prompt with no errors shown. |
| `npm run lint` | Exit 0. | No lint errors shown. The parser warned that installed TypeScript 5.6.3 is outside its supported range (>=4.7.4 and <5.6.0). |
| `npm run build` | Vite 5.4.8. 1571 modules in 1.86 s. JS 162.55 kB (51.40 kB gzip). Outdated caniuse-lite warning. Exit 0. | Built 1571 modules in 2.26 s with Vite 5.4.8. HTML 0.71 kB, CSS 15.13 kB, JS 162.34 kB (51.35 kB gzip). Same Browserslist warning. |
| `npm run audit` | One high-severity ws finding via Supabase. Exit 1. | `npm audit --omit=dev` reported 0 vulnerabilities. |
| `npm run dev` | Not run. | Launch command not shown. My screenshots document the desktop interaction below. |

**Desktop UI check.** I entered 660 and 720 with Room blocked off. The page showed Available. The explanation identified Room 301 and the interval 11:00 to 12:00. This checks the right endpoint of the fixed booking in the UI. My screenshots are in `evidence/desktop-available.png` and `evidence/desktop-explanation.png`. In a separate live check, Codex opened the same app in a narrow VS Code browser panel. The viewport indicator showed 463.2 by 675.2 CSS pixels. With the inputs still at 660 and 720, Codex enabled Room blocked and clicked Check availability. The result changed to Unavailable and the page explained that the room was blocked. The controls stacked vertically and the result was readable. The cropped screenshot is in `evidence/narrow-blocked.png`. This check covers the narrow desktop viewport used for the test.

The ZIP has no format or coverage script. I count the unused production dependency, the wording-dependent reason codes and the missing merge review instructions as concrete baseline weaknesses. Sections 5 and 8 give their evidence.

## 3 AGENTS.md summary

The project already had a root instructions file. Codex explicitly read it before editing the export. It describes the UI and pure modules, gives the install and check commands, and requires small changes, fresh fixtures and clear test evidence. It also preserves the strict 09:00 boundary, forbids secrets and deployment, and excludes the intentional exercise. It asks for desktop and mobile screenshots. I supplied the desktop screenshots. Codex supplied a screenshot of the narrow layout with the room blocked.

The final file adds instructions to use an isolated copy, avoid destructive commands and present the full diff and check results to me. Dependency changes and their lockfile changes require my approval before merge. The addition is visible in the supplied diff.

## 4 Pattern decision

I kept the existing explanation adapter. It already lets tests replace the local mock with a failing or slow implementation. The checker has one policy for one room, so I could not justify adding Strategy. My maintenance problem was smaller. Before the change, the checker returned a rejection message and the explanation module matched its English prefix. After the change, each rejection carries a typed code and display text. The explanation reads the code directly. The extra field changes the shape of unavailable verdicts. The included tests retain their checks on the original wording. Section 8 records the behavior checks.

## 5 Risk findings with statuses

| ID | Category and status | Evidence and interpretation |
|---|---|---|
| R1 | Dependency · Confirmed | The baseline manifest and lockfile contain Supabase and ws. The app source does not import Supabase. My audit flagged ws. Reachability in the running app is Plausible/unverified. |
| R2 | Maintainability · Confirmed | Baseline reasonCodeFor matches English prefixes. The copy-edit test changed only the overlap message and got UNAVAILABLE instead of OVERLAP. |
| R3 | Agent operations · Confirmed | The original AGENTS.md asks for checks but gives no explicit human merge or lockfile approval gate. |
| R4 | Verification · Confirmed | The export has three module test files and no GitHub Actions workflow. The presence of external CI is unknown. A responsive layout regression is Plausible/unverified. |
| R5 | Correctness · Plausible/unverified | isValidResponse checks status, reason code and text shape. A future adapter could return contradictory prose with correct metadata. The current default uses the local mock. |
| R6 | Correctness · Unsupported | The claim that the app rejects a request beginning at 660 conflicts with the strict overlap comparison, the existing endpoint test and the successful Node endpoint check. |
| R7 | Development dependencies · Confirmed | My full install audit reported 24 findings. My production-only audit reported zero. The screenshots do not identify affected packages or show reachability. |

## 6 Risk register

I use likelihood and impact estimates from 1 to 3. Each score is their product. I own the follow-up for every row. Residual scores are my estimates for this export. They are separate from measured test results.

| ID and component | Cause → event → consequence | Initial L×I | Action, verification and residual |
|---|---|---|---|
| R1 · manifest and lockfile | Unused Supabase brought ws into the production tree and triggered a high-severity audit finding. | 2×3=6 | Removed Supabase. Lockfile check passed and my production audit reported zero. Residual 1×2=2 for future dependency changes. |
| R2 · availability and explanation | Editing a message changed its code and lost the specific reason. | 3×2=6 | The copy-edit regression, final Vitest suite and typecheck passed. Residual 1×1=1. |
| R3 · AGENTS.md | Missing approval gate → agent could merge a dependency change → unreviewed changes enter the branch. | 2×2=4 | Add owner review instructions. Inspect the diff and confirm branch settings separately. 1×2=2. |
| R4 · verification | No workflow in export → manual checks could be skipped → a regression reaches review. | 2×2=4 | The two UI checks are recorded in section 2. I will keep the checks in my review routine. Residual 2×2=4 because automated enforcement is still unverified. |
| R5 · explanation adapter | Future adapter produces contradictory prose → validator accepts it → misleading explanation. | 1×2=2 | Keep the local mock. Test any future adapter against known verdicts before enabling it. 1×2=2. |
| R6 · overlap rule | Claimed endpoint bug would block a valid interval. Evidence rejects the claim. | N/A | Keep endpoint tests. No established residual defect. |
| R7 · development toolchain | Affected packages in the full install could expose development or build work to known issues. | 2×3=6 | I will inspect the full npm audit dependency paths, prioritize the critical and high findings, and retest reviewed updates. Residual 2×3=6 until triage. |

R1 and R2 were the two confirmed baseline risks selected for changes. My final install added R7 to the register. It remains open.

## 7 Agent-readiness audit

**Level 2 — Documented.** I can trace the entry point, run the commands from the README and install pinned versions from the lockfile when the registry is available. AGENTS.md documents scope, permissions and review gates. The explanation module provides a fallback when the adapter fails. The UI displays a standard explanation, but the supplied implementation gives limited diagnostic detail about the cause.

My Windows run confirms installation, tests, typecheck, lint, build and the production audit. Level 2 remains appropriate. I still need evidence of human diff approval and triage of the development dependency findings.

## 8 Two mitigations and verification

**R1. Remove the unused dependency.** Codex searched the application source and ran `npm uninstall @supabase/supabase-js --package-lock-only --offline --ignore-scripts --no-audit --no-fund` in the isolated copy. It reviewed the manifest and lockfile changes. Fifteen package entries disappeared, including ws. No new entry appeared. The root manifest entry was the only retained lockfile entry whose contents changed. The exercise copy keeps its original dependencies. The focused test checks the main app only.

**R2. Preserve the reason code when wording changes.** Codex changed the unavailable verdict type, assigned a code in each rejecting branch and removed prefix matching. It updated expected verdicts and added a Vitest test for edited display text. The diff preserves the original overlap comparison and message assertions. The final Vitest run passed all 17 explanation tests, including the new regression.

Codex ran the same dependency-free checks with Node 24.13.1 against both exports. The harness, logs and complete source diff are included. From the package root, the final run can be repeated with `node evidence/checks05.mjs project`. The baseline command used the same harness with the original extracted project as its argument.

| Actual result | Baseline export | Final export |
|---|---|---|
| Dependency and lockfile assertion | Failed | Passed |
| Reason code after changing only the displayed overlap message | Failed | Passed |
| Ten boundary cases, including the booking-array check on every call | 10 passed | 10 passed |
| Node total | 10/12 passed, exit 1 | 12/12 passed, exit 0 |

I ran the Linux baseline and the final Windows project checks. Codex ran the separate 12-case comparison and inspected the diff. I still need to record my personal review of that diff.

## 9 Background-agent safeguards

I would start an agent on a separate worktree and a branch named review/reason-codes from the reviewed version. Its task would be to add a test for one more display wording change. It may edit only src/explanation.test.ts. It may inspect the source, run the existing tests, typecheck, lint and build, and show git diff. I would give it 30 minutes.

I would prohibit dependency changes, deployments, credentials, pushes, merges, destructive commands and edits to the exercise. The agent must return its diff, change summary, test logs, build result and remaining concerns. If a check fails, it must stop and preserve the branch for inspection. I would review the diff before merge. To roll back an unmerged attempt, I can keep using the original branch. A merged change would require a reviewed revert.

## 10 Release decision

**CONDITIONAL for a local classroom demo.** All 29 project tests passed. Typecheck and lint showed no errors, the production build succeeded, and the production dependency audit reported zero findings. Before I approve a merge, I will review the diff. Codex verified the blocked result in the narrow layout. Before I expand use beyond the local demo, I will review the full audit, starting with the two critical and thirteen high findings. I will also track the parser and Browserslist warnings. Deployment remains outside my project scope.

## 11 AI reflection

I used ChatGPT Codex to help me review my Room 301 checker. I gave it my repository name, baseline commit, configuration details and Linux command results. It also had the assignment brief, five source files and the project archive. I personally ran the baseline commands after installing from the lockfile. Codex ran the later checks on an isolated copy. I use that distinction when I describe the results.

One useful suggestion was to test whether changing a message could change its meaning inside the program. The original code recognized an overlap by reading the first words of the English message. A small test showed the problem. When the words changed, the code stopped recognizing the overlap. With a typed reason code, the same test passed. A weak part of the first draft was its assessment of the repository instructions. It treated their contents as missing even though I had supplied an archive. Reading the actual file changed the readiness assessment.

I then ran the final checks on my Windows machine. All 29 tests passed, including the added regression. The build succeeded and the production audit reported zero findings. The full installation still reported 24 vulnerabilities. That difference led me to choose a conditional local demo while I review the development tools. The instructions helped me preserve the intentional exercise and the strict 09:00 rule. Codex checked the blocked state in a narrow browser panel. My own final diff review remains open.

## 12 AI-use record and evidence appendix

**Tool and date.** ChatGPT Codex, GPT-6 family, 21 November 2026. The assistant used for the archive review was GPT-6.2-astra. No second-tool output was supplied.

| Prompt or context | Output used | Problem, revision and evidence |
|---|---|---|
| I requested a first-person report and supplied the baseline. | Project description, commands and acceptance criteria. | The first criteria missed blocked rooms and endpoint behavior. The README, implementation and fixtures supplied the exact rules. |
| I provided five source files and requested a risk review. | Candidate findings, proposed mitigations and release decision. | Source inspection supports the dependency and reason-code findings. The earlier missing-file assumption was corrected from the ZIP. |
| I asked Codex to complete the assignment and pointed out my ZIP. | Final source edits, focused tests, diff, logs, estimates and report. | Its restricted npm run could not verify the project checks. It recorded the failed attempts. |
| I supplied three terminal screenshots of my final Windows run. | Updated sections 2, 5–8 and 10–12 using my results. | The two audit scopes differ. I recorded both totals and kept development dependency triage open. |
| I supplied two screenshots of the running checker. | Codex documented the open-room verdict and mock explanation in the report. | Both images show the wide layout. |

| I asked Codex to take control of the screen and finish the UI check. | Codex checked the blocked verdict at 463.2 CSS pixels and saved the narrow panel screenshot. | The screenshot and on-screen field values were checked in the live VS Code preview. |

**Read-only prompt prepared for independent use.** “Review the supplied source, AGENTS.md, configs and command logs. Do not edit files or run commands. Report five candidate risks across three categories. For each, cite a path, function or command and identify what would confirm or disprove it. Distinguish an installed advisory from a reachable runtime issue.”

**Review material.** Section 5 records the evaluated findings from this session. The evidence directory contains the focused runner, before/after logs, logs of the earlier Codex npm attempts, a transcription of my Windows results, the full unified diff and final source hashes. The original ZIP and the Git reference in section 1 identify the baseline. I still need to record my own final review and any independent AI response I use.
